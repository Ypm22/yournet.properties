YOURNET PROPERTY MAINTENANCE LLC WEBSITE
========================================

Files:
- index.html  Main website
- styles.css  Design and responsive layout
- script.js   Estimate form behavior
- website-preview.png  Visual homepage concept

To publish:
1. Upload these files to a static website host.
2. Connect your domain name.
3. Replace the gallery placeholders with your real project photos.
4. Replace the text-logo mark with the official Yournet logo if desired.
5. For a true online form that sends submissions without opening email, connect the form to a form service or business email backend.

The current estimate form opens the visitor's email app and prepares an email to yournet.properties@gmail.com.
